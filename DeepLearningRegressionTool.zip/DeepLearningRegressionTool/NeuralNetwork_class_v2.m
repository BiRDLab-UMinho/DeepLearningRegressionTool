classdef NeuralNetwork_class_v2 < handle
    methods           
        function [Train] = GetTrainData(obj,dir,train_,totalTrialsub,NoVelocities)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to get the data for the cross-validation training. Data should be stored in disk.
            % This function should be modified by each user.
            % 
            % Returns:
            %           - struct Train with two fields: 
            %               1) Train.Predictors -> N-by-P, N is the number of observations and P is the number of signals
            %               2) Train.Response -> N-by-1, N is the number of observations
            % ----------------------------------------------------------------------------------------------------------

            for i = 1:length(train_)
                idx = int2str(train_(1,i));
                data = struct2cell(load(strcat(dir,'\Subject',idx,'.mat')));

                new_data{i,1} = array2table(data{1,1},'VariableNames',{'Ang','Vel','Acc','TA','GAL','Age','Gender','BH','BM','SL','FL','Speed','Tor'});
            end
            
            ini_pos = 1;
            no_samples = totalTrialsub * NoVelocities;
            fin_pos = no_samples;
            
            for i = 1:length(new_data)
                XTrain(ini_pos:fin_pos,:) = table2array(new_data{i,1}(:,1:12));
                YTrain(ini_pos:fin_pos,:) = table2array(new_data{i,1}(:,13));
                ini_pos = ini_pos + no_samples;
                fin_pos = fin_pos + no_samples;
            end
            
            Train.Predictors = XTrain;
            Train.Response = YTrain;
        end
        
        function [Test] = GetTestData(obj,dir,test,totalTrialsub,NoVelocities)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to get the test data for the final's model construction. 
            % Data should be stored in disk.
            % This function should be modified by each user.
            % 
            % Returns:
            %           - struct Test with two fields: 
            %               1) Test.Predictors -> N-by-P, N is the number of observations and P is the number of signals
            %               2) Test.Response -> N-by-1, N is the number of observations
            % ----------------------------------------------------------------------------------------------------------

            idx = int2str(test);
            data = struct2cell(load(strcat(dir,'\Subject',idx,'.mat')));

            new_data = array2table(data{1,1},'VariableNames',{'Ang','Vel','Acc','TA','GAL','Age','Gender','BH','BM','SL','FL','Speed','Tor'});

            ini_pos = 1;
            no_samples = totalTrialsub * NoVelocities;
            fin_pos = no_samples;
            
            XTest(ini_pos:fin_pos,:) = table2array(new_data(:,1:12));
            YTest(ini_pos:fin_pos,:) = table2array(new_data(:,13));
            ini_pos = ini_pos + no_samples;
            fin_pos = fin_pos + no_samples;
            
            Test.Predictors = XTest;
            Test.Response = YTest;
        end

        function [newData4CV, newData4TestFinalModel] = clearNANvalues(obj,Data4CV, Data4TestFinalModel)
            newData4CV = Data4CV;
            newData4TestFinalModel = Data4TestFinalModel;

            % correct the first and the last NaN value of the training and
            % test datasets
            
            % Searching NaN in newData4CV.Response and transform them in a
            % number
            for i = 1:length(newData4CV.Response)
                if isnan(newData4CV.Response(i,1)) == 1                     % se i é NaN
                    if i == 1
                        newData4CV.Response(1,1) = newData4CV.Response(2,1) - 0.00005;
                    elseif i == length(newData4CV.Response)
                        newData4CV.Response(end,1) = newData4CV.Response(end-1,1) - 0.00005;
                    else
                        if isnan(newData4CV.Response(i+1,1)) == 1           % se i e i+1 são NaN
                            if isnan(newData4CV.Response(i+2,1)) == 0       % se i+2 não é NaN
                                newData4CV.Response(i,1) = newData4CV.Response(i-1,1) - 0.00005;
                                newData4CV.Response(i+1,1) = newData4CV.Response(i+2,1) - 0.00005;
                            elseif isnan(newData4CV.Response(i+2,1)) == 1   % se i+2 é NaN
                                newData4CV.Response(i,1) = newData4CV.Response(i-1,1) - 0.00005;
                                newData4CV.Response(i+2,1) = newData4CV.Response(i+3,1) - 0.00005;
                                newData4CV.Response(i+1,1) = (newData4CV.Response(i,1) + newData4CV.Response(i+2,1))/2 - 0.00005;
                            end
                        else                                                % se i+1 não é NaN
                            numbers = [i-2,i-1,i+1,i+2]; 
                            newData4CV.Response(i,1) = sum(newData4CV.Response(numbers,1))/4;                
                        end
                    end
                end
            end 

            % Searching NaN in newData4CV.Predictors and transform them in a
            % number
            for i = 1:length(newData4CV.Predictors)
                for j = 1:3
                    if isnan(newData4CV.Predictors(i,j)) == 1                     % se i é NaN
                        if i == 1
                            newData4CV.Predictors(1,j) = newData4CV.Predictors(2,j) - 0.00005;
                        elseif i == length(newData4CV.Predictors)
                            newData4CV.Predictors(end,j) = newData4CV.Predictors(end-1,j) - 0.00005;
                        else
                            if isnan(newData4CV.Predictors(i+1,j)) == 1           % se i e i+1 são NaN
                                if isnan(newData4CV.Predictors(i+2,j)) == 0       % se i+2 não é NaN
                                    newData4CV.Predictors(i,j) = newData4CV.Predictors(i-1,j) - 0.00005;
                                    newData4CV.Predictors(i+1,j) = newData4CV.Predictors(i+2,j) - 0.00005;
                                elseif isnan(newData4CV.Predictors(i+2,j)) == 1   % se i+2 é NaN
                                    newData4CV.Predictors(i,j) = newData4CV.Predictors(i-1,j) - 0.00005;
                                    newData4CV.Predictors(i+2,j) = newData4CV.Predictors(i+3,j) - 0.00005;
                                    newData4CV.Predictors(i+1,j) = (newData4CV.Predictors(i,j) + newData4CV.Predictors(i+2,j))/2 - 0.00005;
                                end
                            else                                                % se i+1 não é NaN
                                numbers = [i-2,i-1,i+1,i+2]; 
                                newData4CV.Predictors(i,j) = sum(newData4CV.Predictors(numbers,j))/4;                
                            end
                        end
                    end
                end
            end 


            % Searching NaN in newData4TestFinalModel.Response and transform them in a
            % number
            for i = 1:length(newData4TestFinalModel.Response)
                if isnan(newData4TestFinalModel.Response(i,1)) == 1                     % se i é NaN
                    if i == 1
                        newData4TestFinalModel.Response(1,1) = newData4TestFinalModel.Response(2,1) - 0.00005;
                    elseif i == length(newData4TestFinalModel.Response)
                        newData4TestFinalModel.Response(end,1) = newData4TestFinalModel.Response(end-1,1) - 0.00005;
                    else
                        if isnan(newData4TestFinalModel.Response(i+1,1)) == 1           % se i e i+1 são NaN
                            if isnan(newData4TestFinalModel.Response(i+2,1)) == 0       % se i+2 não é NaN
                                newData4TestFinalModel.Response(i,1) = newData4TestFinalModel.Response(i-1,1) - 0.00005;
                                newData4TestFinalModel.Response(i+1,1) = newData4TestFinalModel.Response(i+2,1) - 0.00005;
                            elseif isnan(newData4TestFinalModel.Response(i+2,1)) == 1   % se i+2 é NaN
                                newData4TestFinalModel.Response(i,1) = newData4TestFinalModel.Response(i-1,1) - 0.00005;
                                newData4TestFinalModel.Response(i+2,1) = newData4TestFinalModel.Response(i+3,1) - 0.00005;
                                newData4TestFinalModel.Response(i+1,1) = (newData4TestFinalModel.Response(i,1) + newData4TestFinalModel.Response(i+2,1))/2 - 0.00005;
                            end
                        else                                                % se i+1 não é NaN
                            numbers = [i-2,i-1,i+1,i+2];
                            newData4TestFinalModel.Response(i,1) = sum(newData4TestFinalModel.Response(numbers,1))/4;                
                        end
                    end
                end
            end  

            % Searching NaN in newData4TestFinalModel.Predictors and transform them in a
            % number
            for i = 1:length(newData4TestFinalModel.Predictors)
                for j = 1:3
                    if isnan(newData4TestFinalModel.Predictors(i,j)) == 1                     % se i é NaN
                        if i == 1
                            newData4TestFinalModel.Predictors(1,j) = newData4TestFinalModel.Predictors(2,j) - 0.00005;
                        elseif i == length(newData4TestFinalModel.Predictors)
                            newData4TestFinalModel.Predictors(end,j) = newData4TestFinalModel.Predictors(end-1,j) - 0.00005;
                        else
                            if isnan(newData4TestFinalModel.Predictors(i+1,j)) == 1           % se i e i+1 são NaN
                                if isnan(newData4TestFinalModel.Predictors(i+2,j)) == 0       % se i+2 não é NaN
                                    newData4TestFinalModel.Predictors(i,j) = newData4TestFinalModel.Predictors(i-1,j) - 0.00005;
                                    newData4TestFinalModel.Predictors(i+1,j) = newData4TestFinalModel.Predictors(i+2,j) - 0.00005;
                                elseif isnan(newData4TestFinalModel.Predictors(i+2,j)) == 1   % se i+2 é NaN
                                    newData4TestFinalModel.Predictors(i,j) = newData4TestFinalModel.Predictors(i-1,j) - 0.00005;
                                    newData4TestFinalModel.Predictors(i+2,j) = newData4TestFinalModel.Predictors(i+3,j) - 0.00005;
                                    newData4TestFinalModel.Predictors(i+1,j) = (newData4TestFinalModel.Predictors(i,j) + newData4TestFinalModel.Predictors(i+2,j))/2 - 0.00005;
                                end
                            else                                                % se i+1 não é NaN
                                numbers = [i-2,i-1,i+1,i+2];
                                newData4TestFinalModel.Predictors(i,j) = sum(newData4TestFinalModel.Predictors(numbers,j))/4;                
                            end
                        end
                    end
                end
            end 

            
            % Verify if newData4CV and newData4TestFinalModel have NaN
            % values remaining
            % newData4CV.Response
            countNaNData4CVResponse = 0;
            for i = 1:length(newData4CV.Response)
                if isnan(newData4CV.Response(i,1)) == 1
                    countNaNData4CVResponse = countNaNData4CVResponse + 1;
                end
            end
            if countNaNData4CVResponse ~= 0 
                sprintf("There are %d NaN values remaining in 'newData4CV.Response'", countNaNData4CVResponse)
            end

            % newData4CV.Predictors
            countNaNData4CVPredictors = 0;
            for i = 1:length(newData4CV.Response)
                if isnan(newData4CV.Response(i,1)) == 1
                    countNaNData4CVPredictors = countNaNData4CVPredictors + 1;
                end
            end
            if countNaNData4CVPredictors ~= 0 
                sprintf("There are %d NaN values remaining in 'newData4CV.Predictors'", countNaNData4CVPredictors)
            end
            
            % newdata4TestFinalModel.Response
            countNaNData4TestFinalModelResponse = 0;
            for i = 1:length(newData4TestFinalModel.Response)
                if isnan(newData4TestFinalModel.Response(i,1)) == 1 
                    countNaNData4TestFinalModelResponse = countNaNData4TestFinalModelResponse + 1;
                end
            end
            if countNaNData4TestFinalModelResponse ~= 0 
                sprintf("There are %d NaN values remaining in 'newData4TestFinalModel.Response'", countNaNData4TestFinalModelResponse)
            end

            % newdata4TestFinalModel.Predictors
            countNaNData4TestFinalModelPredictors = 0;
            for i = 1:length(newData4TestFinalModel.Response)
                if isnan(newData4TestFinalModel.Response(i,1)) == 1 
                    countNaNData4TestFinalModelPredictors = countNaNData4TestFinalModelPredictors + 1;
                end
            end
            if countNaNData4TestFinalModelPredictors ~= 0 
                sprintf("There are %d NaN values remaining in 'newData4TestFinalModel.Predictors'", countNaNData4TestFinalModelPredictors)
            end


        end
        


        function Train = ShuffleData(obj,TrainData,trial_length)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to shuffle the train data considering trials. This configuration was adopted to have
            % the same shuffle for LSTM, CNN and MLP. The user can adopt an additional shuffle using the trainingOptions
            % of the MATLAB's tool for neural networks.
            % 
            % Inputs:
            %           - TrainData -> struct with Train.Predictors & Train.Response
            %           - trial_length -> length of each subject's trial
            % Returns:
            %           - struct Train with two fields: 
            %               1) Train.Predictors -> N-by-P, N is the number of observations and P is the number of signals
            %               2) Train.Response -> N-by-1, N is the number of observations
            % ----------------------------------------------------------------------------------------------------------
            
            [line,~]= size(TrainData.Predictors);
            groups = line/trial_length;
            
            XTrain = cell(groups,1);
            YTrain = cell(groups,1);
            
            z = 1;
            for i = 1:trial_length:line
                XTrain{z} = TrainData.Predictors(i:i+trial_length-1,:);
                YTrain{z} = TrainData.Response(i:i+trial_length-1,:);
                z = z + 1;
            end
            
            % shuffle data
            sequence = randperm(groups);
            XTrain = XTrain(sequence);
            YTrain = YTrain(sequence);
            
            % convert to mat again
            Train.Predictors = cell2mat(XTrain);
            Train.Response = cell2mat(YTrain);            
        end
        
        function [layers,options] = GenerateLSTM(obj,numFeatures,numHiddenUnits,numResponses,p,maxEpochs,BatchSize,ValData,...
                ValFrequency,StopVal,checkpointPath,desired_option)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to generate the LSTM neural network.
            % 
            % Inputs:
            %           - numFeatures -> number of signals used for the regression problem
            %           - numHiddenUnits -> number of neurons of the LSTM Layer 
            %           - numResponses -> number of responses of the fully connected layer (should be 1 for seq-to-seq)
            %           - p -> probability for the dropout regularization layer
            %           - maxEpochs -> number maximum of epochs
            %           - BatchSize -> number of sequences to group
            %           - ValData -> struct of validation data containing ValData.Predictors and ValData.Response
            %           - ValFrequency -> frequency of validation during the training process
            %           - StopVal -> if early stop is required, define a resonable number of epochs. If not required, 
            %                       StopVal should assume the same number of epochs of maxEpochs.
            %           - checkpointPath -> path to create and save the neural network's checkpoint file.
            %           - desired_option -> can assume to values: 1) for cross-validation and 2) for houldout method.
            %                       If houldout is specified, a function for early stop is implemented.
            % Returns:
            %           - struct Train with two fields: 
            %               1) layers -> LSTM layers with the options specified by the user
            %               2) options -> training options specified by the user
            % ----------------------------------------------------------------------------------------------------------
            
            layers = [ ...
                sequenceInputLayer(numFeatures)
                lstmLayer(numHiddenUnits,'OutputMode','sequence')
                dropoutLayer(p)
                fullyConnectedLayer(numResponses)
                regressionLayer];
                
            if desired_option == 1
                options = trainingOptions('adam', ...
                    'MaxEpochs',maxEpochs, ...
                    'MiniBatchSize',BatchSize, ...
                    'InitialLearnRate',0.01, ...
                    'GradientThreshold',1, ...
                    'Shuffle','never', ...
                    'Plots','training-progress',...
                    'ExecutionEnvironment','cpu',...
                    'Verbose',0,...
                    'ValidationData',{ValData.Predictors,ValData.Response},...
                    'ValidationFrequency',ValFrequency,...
                    'GradientThresholdMethod','l2norm',...
                    'CheckpointPath',checkpointPath);
            else
                options = trainingOptions('adam', ...
                    'MaxEpochs',maxEpochs, ...
                    'MiniBatchSize',BatchSize, ...
                    'InitialLearnRate',0.01, ...
                    'GradientThreshold',1, ...
                    'Shuffle','never', ...
                    'Plots','training-progress',...
                    'ExecutionEnvironment','cpu',...
                    'Verbose',0,...
                    'ValidationData',{ValData.Predictors,ValData.Response},...
                    'ValidationFrequency',ValFrequency,...
                    'GradientThresholdMethod','l2norm',...
                    'CheckpointPath',checkpointPath,...
                    'OutputFcn',@(info)stopIfAccuracyNotImproving(info,StopVal));
            end
        end
        
        % Generate CNN
        function [layers,options] = GenerateCNN(obj,Width,numResponses,p,maxEpochs,BatchSize,ValData,...
                ValFrequency,StopVal,checkpointPath,desired_option)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to generate the CNN neural network.
            % 
            % Inputs:
            %           - Height -> height of the input image
            %           - Width -> width of the input image 
            %           - Channels -> number of channels of the input image
            %           - numResponses -> number of responses of the fully connected layer (should be 1 for point-to-point)
            %           - p -> probability for the dropout regularization layer
            %           - maxEpochs -> number maximum of epochs
            %           - BatchSize -> number of sequences to group
            %           - ValData -> struct of validation data containing ValData.Predictors and ValData.Response
            %           - ValFrequency -> frequency of validation during the training process
            %           - StopVal -> if early stop is required, define a resonable number of epochs. If not required, 
            %                       StopVal should assume the same number of epochs of maxEpochs.
            %           - checkpointPath -> path to create and save the neural network's checkpoint file.
            %           - desired_option -> can assume to values: 1) for cross-validation and 2) for houldout method.
            %                       If houldout is specified, a function for early stop is implemented.
            % Returns:
            %           - struct Train with two fields: 
            %               1) layers -> CNN layers with the options specified by the user
            %               2) options -> training options specified by the user
            % ----------------------------------------------------------------------------------------------------------
            
            % exemplo Luís Moreira
            filterSize = 2; % começar por 5, 10, 20, 30, 40...
            noFilter = 8;   % começar com 8 e ir para os múltiplos de 8
        
            layers = [
                sequenceInputLayer(Width,'normalization','none') 
                % 1ª layer
                convolution1dLayer(filterSize,noFilter,'Padding','same') 
%                 batchNormalizationLayer
                reluLayer
                dropoutLayer(p)
                averagePooling1dLayer(2,"Padding","same", Stride=2)
%                 % 2ª layer
                convolution1dLayer(filterSize,16,'Padding','same')
%                 batchNormalizationLayer
                reluLayer
%                 averagePooling1dLayer(2,"Padding","same", Stride=2) 
                dropoutLayer(p)
                globalAveragePooling1dLayer 
                %fullyConnectedLayer(10)
                fullyConnectedLayer(numResponses)
                regressionLayer];

             % exemplo Rautela
%             layers = [
%                 sequenceInputLayer(Width,'normalization','none') 
%                 % 1ª layer
%                 convolution1dLayer(3,16,'Padding','same') 
%                 leakyReluLayer
%                 maxPooling1dLayer(2,"Padding","same", Stride=1)
%                 % 2ª layer
%                 convolution1dLayer(3,32,'Padding','same')
%                 leakyReluLayer
%                 maxPooling1dLayer(2,"Padding","same", Stride=1)
%                 %3ª layer
%                 convolution1dLayer(3,64,'Padding','same') 
%                 leakyReluLayer
%                 maxPooling1dLayer(2,"Padding","same", Stride=1)
%                 flattenLayer
%                 fullyConnectedLayer(64)
%                 leakyReluLayer
%                 dropoutLayer(p)
%                 globalAveragePooling1dLayer 
%                 fullyConnectedLayer(numResponses)
%                 regressionLayer];


%             layers = [
%                 sequenceInputLayer(Width,'normalization','zerocenter') 
%                 % 1ª layer
%                 convolution1dLayer(150,20,'Padding','same') 
%                 batchNormalizationLayer
%                 reluLayer
%                 maxPooling1dLayer(2,"Padding","same", Stride=2)
%                 % 2ª layer
%                 convolution1dLayer(150,40,'Padding','same')
%                 batchNormalizationLayer
%                 reluLayer
%                 %3ª layer
%                 convolution1dLayer(10,60,'Padding','same') 
%                 batchNormalizationLayer
%                 reluLayer
%                 %4ª layer
%                 convolution1dLayer(10,60,'Padding','same') 
%                 batchNormalizationLayer
%                 reluLayer
%                 %5ª layer
%                 convolution1dLayer(20,60,'Padding','same') 
%                 batchNormalizationLayer
%                 reluLayer
%                 %6ª layer
%                 convolution1dLayer(10,60,'Padding','same') 
%                 batchNormalizationLayer
%                 reluLayer
%                 dropoutLayer(p)  
%                 globalAveragePooling1dLayer 
%                 fullyConnectedLayer(numResponses)
%                 regressionLayer];

            
            if desired_option == 1
                options = trainingOptions('adam', ...
                    'MaxEpochs',maxEpochs, ...
                    'MiniBatchSize',BatchSize, ...
                    'InitialLearnRate',0.01, ...
                    'GradientThreshold',1, ...
                    'Shuffle','never', ...
                    'Plots','training-progress',...  % 'training-progress'
                    'ExecutionEnvironment','gpu',...
                    'Verbose',0,...
                    'ValidationData',{ValData.Predictors,cell2mat(ValData.Response)},...
                    'ValidationFrequency',ValFrequency,...
                    'GradientThresholdMethod','l2norm',...
                    'CheckpointPath',checkpointPath);
            else
                options = trainingOptions('adam', ...
                    'MaxEpochs',maxEpochs, ...
                    'MiniBatchSize',BatchSize, ...
                    'InitialLearnRate',0.01, ...
                    'GradientThreshold',1, ...
                    'Shuffle','never', ...
                    'Plots','training-progress',... % 'training-progress'
                    'ExecutionEnvironment','gpu',...
                    'Verbose',0,...
                    'ValidationData',{ValData.Predictors,cell2mat(ValData.Response)},...
                    'ValidationFrequency',ValFrequency,...
                    'GradientThresholdMethod','l2norm',...
                    'CheckpointPath',checkpointPath,...
                    'OutputFcn',@(info)stopIfAccuracyNotImproving(info,StopVal));
            end
% 
%             lgraph = layerGraph(layers);
%             analyzeNetwork(lgraph)
        end
        
        % Generate MLP
        function net = GenerateMLP(obj,NoNeurons,trainFcn,divideFcn,epochs,min_grad,goal,max_fail,trainInd,valInd)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to generate the MLP neural network.
            % 
            % Inputs:
            %           - NoNeurons -> number of neurons of the neural network. Could be 10, for one fully connected layer
            %               of 10 neurons or [10, 10] for two fully connected layers of 10 neurons each.
            %           - trainFcn -> function of optimization (traingdx, trainlm, etc)
            %           - divideFcn -> function to divide the data into training and validation. To specify the validation
            %               data, divideFcn should assume "divideind".
            %           - epoch -> number maximum of epochs
            %           - min_grad -> minimum gradient to expect
            %           - goal -> the mse goal of the neural network
            %           - max_fail -> if early stop is required, specify a resonable number of epochs. If not, max_fail
            %               should be equal to epoch.
            %           - trainInd, valInd -> indexs for the division into training and validation data.
            % Returns:
            %           - struct Train with two fields: 
            %               1) net -> MLP neural network with the required options.
            % ----------------------------------------------------------------------------------------------------------

            net = fitnet(NoNeurons,trainFcn);
            net.trainParam.epochs = epochs;
            net.divideParam.trainRatio = 1;
            net.divideParam.valRatio = 0;
            net.divideParam.testRatio = 0;
            net.trainParam.min_grad = min_grad;
            net.trainParam.goal = goal;
            net.trainParam.max_fail = max_fail;
            net.trainParam.showWindow=1;
            net.divideFcn = divideFcn;
            net.divideParam.trainInd = trainInd;
            net.divideParam.valInd = valInd;
        end
        
        function [Train, Validation] = Train_Val_Sequence(obj,trainData,valData,len,type_net)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to divide the training and validation data into sequences.
            % 
            % Inputs:
            %           - trainData -> struct containing Train.Predictors and Train.Response data.
            %           - valData -> struct containing Validation.Predictors and Validation.Response data.
            %           - len -> sequence length
            % Returns: 
            %           - Train -> struct containing Train.Predictors (cell with P-by-M in which M is the sequence length)
            %               and Train.Response (cell with M-by-1)
            %           - Validation -> struct containing Validation.Predictors and Validation.Response
            % ----------------------------------------------------------------------------------------------------------
            
            XTrainSeq = {};
            YTrainSeq = {};

            if (strcmp(type_net,'LSTM'))
                line = 1;
                for col = 1:len:length(trainData.Predictors)
                    XTrainSeq{line,1} = (trainData.Predictors(col:col+len-1,:))';
                    YTrainSeq{line,1} = (trainData.Response(col:col+len-1))';
                    line = line + 1;
                end
            elseif (strcmp(type_net,'CNN')) % conjuntos de amostras movendo a janela apenas 1 amostra para a frente
                line = 1;
                for lin = 1:(length(trainData.Predictors)-len+1)
                    XTrainSeq{line,1} = (trainData.Predictors(lin:lin+len-1,:))';
                    YTrainSeq{line,1} = (trainData.Response(len+line-1))';
                    line = line + 1;
                end
            end
            
            Train.Predictors = XTrainSeq;
            Train.Response = YTrainSeq;
            
            XValSeq = {};
            YValSeq = {};
            
            if (strcmp(type_net,'LSTM'))
                line = 1;
                for col = 1:len:length(valData.Predictors)
                    XValSeq{line,1} = (valData.Predictors(col:col+len-1,:))';
                    YValSeq{line,1} = (valData.Response(col:col+len-1))';
                    line = line + 1;
                end
            elseif (strcmp(type_net,'CNN')) % conjuntos de amostras movendo a janela apenas 1 amostra para a frente
                line = 1;
                for lin = 1:(length(valData.Predictors)-len+1)
                    XValSeq{line,1} = (valData.Predictors(lin:lin+len-1,:))';
                    YValSeq{line,1} = (valData.Response(len+line-1))';
                    line = line + 1;
                end
            end
            
            Validation.Predictors = XValSeq;
            Validation.Response = YValSeq;
        end


        
        function Test = Test_Sequence(obj,testData,len,type_net)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to divide the test data into sequences.
            % 
            % Inputs:
            %           - testData -> struct containing Test.Predictors and Test.Response data.
            %           - len -> sequence length
            % Returns: 
            %           - Test -> struct containing Test.Predictors (cell with P-by-M in which M is the sequence length)
            %               and Test.Response (cell with M-by-1)
            % ----------------------------------------------------------------------------------------------------------
                        
            XTestSeq = {};
            
            if (strcmp(type_net,'LSTM'))
                line = 1;
                for col = 1:len:length(testData)
                    XTestSeq{line,1} = (testData(col:col+len-1,:))';
                    line = line + 1;
                end
                Test = XTestSeq;

            elseif (strcmp(type_net,'CNN'))
                line = 1;
                if size(testData,2) == 12
                    for lin = 1:(length(testData)-len+1)   
                        XTestSeq{line,1} = (testData(lin:lin+len-1,:))';
                        line = line + 1;
                    end
                    Test = XTestSeq;
                elseif size(testData,2) == 1
                    for lin = 1:(length(testData)-len+1)   
                        YTestSeq{line,1} = (testData(len+line-1))';
                        line = line + 1;
                    end
                    Test = YTestSeq;
                end
            end
        end
        
        % Data normalization
        function [Y,Config] = DataNormalization(obj,Data,type_norm,dir)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to normalize the neural network's input data.
            % 
            % Inputs:
            %           - Data -> Matrix N-by-P containing the data to normalize. N is the number of observations and P
            %               is the number of signals.
            %           - type_norm -> type of normalization (can be MAX-MIN, MEAN-STD, MEDIAN, etc)
            %           - dir -> directory to save the configurations
            % Returns: 
            %           - Y -> output with the size of input containing the normalized data.
            %           - Config -> struct containing the configurations for data normalization.
            % ----------------------------------------------------------------------------------------------------------
            
            if (strcmp(type_norm,'MAX-MIN'))
                min_t = -1;
                max_t = 1;
                
                MAX_P = max(Data,[],1);
                MIN_P = min(Data,[],1);
                
                m = (max_t - min_t) ./ (MAX_P-MIN_P);
                b = min_t - m .* MIN_P;
                
                Y = Data .* m + b;
                Config.m = m;
                Config.b = b;
                
                save(dir,'Config','-v7.3');
                
            elseif (strcmp(type_norm,'MEAN-STD'))
                
                Mean = mean(Data,1);
                STD = std(Data,1);
                
                Y = (Data - Mean) ./ STD;
                Config.mean = Mean;
                Config.std = STD;
                
                save(dir,'Config','-v7.3');
                
            elseif (strcmp(type_norm,'MEDIAN'))
                
                th25 = prctile(Data,25);
                th75 = prctile(Data,75);
                Median = median(Data);
                
                Y = (Data - Median) ./ (th75 - th25);
                Config.median = Median;
                Config.th25 = th25;
                Config.th75 = th75;
                
                save(dir,'Config','-v7.3');
                
            else
                error('Error: method not available.');
            end
        end
        
        % Test normalization
        function Y = TestNormalization(obj,Data,Config,type_norm)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to normalize the test data.
            % 
            % Inputs:
            %           - Data -> Matrix N-by-P containing the data to normalize. N is the number of observations and P
            %               is the number of signals.
            %           - Config -> struct with the required configurations to normalize data.
            %           - type_norm -> type of normalization (can be MAX-MIN, MEAN-STD, MEDIAN, etc)
            % Returns: 
            %           - Y -> output with the size of input containing the normalized data.
            % ----------------------------------------------------------------------------------------------------------
            
            if (strcmp(type_norm,'MAX-MIN'))
                Y = Config.m .* Data + Config.b;
            elseif (strcmp(type_norm,'MEAN-STD'))
                Y = (Data - Config.mean) ./ Config.std;
            elseif (strcmp(type_norm,'MEDIAN'))
                Y = (Data - Config.median) ./ (Config.th75 - Config.th25);
            else
                error('Error: method not available.');
            end
        end
        
        % Validation & Test denormalization
        function Y = Denormalization(obj,Data,Config,type_norm)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to denormalize data.
            % 
            % Inputs:
            %           - Data -> Matrix N-by-P containing the data to denormalize. N is the number of observations and P
            %               is the number of signals.
            %           - Config -> struct with the required configurations to normalize data.
            %           - type_norm -> type of normalization (can be MAX-MIN, MEAN-STD, MEDIAN, etc)
            % Returns: 
            %           - Y -> output with the size of input containing the denormalize data.
            % ----------------------------------------------------------------------------------------------------------
            
            if (strcmp(type_norm,'MAX-MIN'))
                Y = (Data - Config.b) / Config.m;
            elseif (strcmp(type_norm,'MEAN-STD'))
                Y = Data * Config.std + Config.mean;
            elseif (strcmp(type_norm,'MEDIAN'))
                Y = Data * (Config.th75 - Config.th25) + Config.median;
            else
                error('Error: method not available.');
            end
        end
        
        % Calculate metrics
        function [mse,nmse,nrmse,pcorr,scorr] = CalculateMetrics(obj,real,output)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to calcule metrics of regression (mse, nmse, nrmse, pcorr, scorr)
            % 
            % Inputs:
            %           - real -> target signal
            %           - output -> neural network's output signal
            % Returns: 
            %           - mse -> mean-squared error
            %           - nmse -> normalized mean-squared error
            %           - nrmse -> normalized root-mean-squared error
            %           - pcorr -> pearson's correlation coefficient
            %           - scorr -> spearman's correlation coefficient
            % ----------------------------------------------------------------------------------------------------------
            
            % mse
            mse = goodnessOfFit(output,real,'MSE');
            
            % normalized mse 
            nmse = goodnessOfFit(output,real,'NMSE');
            
            % normalized rmse
            nrmse = goodnessOfFit(output,real,'NRMSE');
            
            % pearson correlation coefficient
            pcorr = corr(real,output,'Type','Pearson');
            
            % spearman correlation coefficient
            scorr = corr(real,output,'Type','Spearman');
            
        end
        
        % Calculate metrics for heatmap
        function [mse_v,rmse_v,nmse_v,nrmse_v,pcorr_v,scorr_v] = CalculateMetrics4HeatMap(obj,Test_unnorm,real,output)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to calcule metrics of regression (mse, nmse, nrmse, pcorr, scorr)
            % 
            % Inputs:
            %           - real -> target signal
            %           - output -> neural network's output signal
            % Returns: 
            %           - mse -> mean-squared error
            %           - nmse -> normalized mean-squared error
            %           - nrmse -> normalized root-mean-squared error
            %           - pcorr -> pearson's correlation coefficient
            %           - scorr -> spearman's correlation coefficient
            % ----------------------------------------------------------------------------------------------------------
            
            pos10 = 1; pos15 = 1; pos20 = 1; pos25 = 1;
            pos30 = 1; pos35 = 1; pos40 = 1;
            for i = 1:length(Test_unnorm.Predictors)
                if Test_unnorm.Predictors(i,12) == 1
                    real10(pos10,1) = real(i,1);
                    output10(pos10,1) = output(i,1);
                    pos10 = pos10 + 1;
                elseif Test_unnorm.Predictors(i,12) == 1.5
                    real15(pos15,1) = real(i,1);
                    output15(pos15,1) = output(i,1);
                    pos15 = pos15 + 1;
                elseif Test_unnorm.Predictors(i,12) == 2
                    real20(pos20,1) = real(i,1);
                    output20(pos20,1) = output(i,1);
                    pos20 = pos20 + 1;
                elseif Test_unnorm.Predictors(i,12) == 2.5
                    real25(pos25,1) = real(i,1);
                    output25(pos25,1) = output(i,1);
                    pos25 = pos25 + 1;
                elseif Test_unnorm.Predictors(i,12) == 3
                    real30(pos30,1) = real(i,1);
                    output30(pos30,1) = output(i,1);
                    pos30 = pos30 + 1;
                elseif Test_unnorm.Predictors(i,12) == 3.5
                    real35(pos35,1) = real(i,1);
                    output35(pos35,1) = output(i,1);
                    pos35 = pos35 + 1;
                elseif Test_unnorm.Predictors(i,12) == 4
                    real40(pos40,1) = real(i,1);
                    output40(pos40,1) = output(i,1);
                    pos40 = pos40 + 1;
                end
            end
            
            % mse
            mse10 = goodnessOfFit(output10,real10,'MSE');
            mse15 = goodnessOfFit(output15,real15,'MSE');
            mse20 = goodnessOfFit(output20,real20,'MSE');
            mse25 = goodnessOfFit(output25,real25,'MSE');
            mse30 = goodnessOfFit(output30,real30,'MSE');
            mse35 = goodnessOfFit(output35,real35,'MSE');
            mse40 = goodnessOfFit(output40,real40,'MSE');
            
            % rmse
            rmse10 = sqrt(mse10);
            rmse15 = sqrt(mse15);
            rmse20 = sqrt(mse20);
            rmse25 = sqrt(mse25);
            rmse30 = sqrt(mse30);
            rmse35 = sqrt(mse35);
            rmse40 = sqrt(mse40);
            
            % normalized mse 
            nmse10 = goodnessOfFit(output10,real10,'NMSE');
            nmse15 = goodnessOfFit(output15,real15,'NMSE');
            nmse20 = goodnessOfFit(output20,real20,'NMSE');
            nmse25 = goodnessOfFit(output25,real25,'NMSE');
            nmse30 = goodnessOfFit(output30,real30,'NMSE');
            nmse35 = goodnessOfFit(output35,real35,'NMSE');
            nmse40 = goodnessOfFit(output40,real40,'NMSE');
            
            % normalized rmse
            nrmse10 = goodnessOfFit(output10,real10,'NRMSE');
            nrmse15 = goodnessOfFit(output15,real15,'NRMSE');
            nrmse20 = goodnessOfFit(output20,real20,'NRMSE');
            nrmse25 = goodnessOfFit(output25,real25,'NRMSE');
            nrmse30 = goodnessOfFit(output30,real30,'NRMSE');
            nrmse35 = goodnessOfFit(output35,real35,'NRMSE');
            nrmse40 = goodnessOfFit(output40,real40,'NRMSE');
            
            % pearson correlation coefficient
            pcorr10 = corr(real10,output10,'Type','Pearson');
            pcorr15 = corr(real15,output15,'Type','Pearson');
            pcorr20 = corr(real20,output20,'Type','Pearson');
            pcorr25 = corr(real25,output25,'Type','Pearson');
            pcorr30 = corr(real30,output30,'Type','Pearson');
            pcorr35 = corr(real35,output35,'Type','Pearson');
            pcorr40 = corr(real40,output40,'Type','Pearson');
            
            % spearman correlation coefficient
            scorr10 = corr(real10,output10,'Type','Spearman');
            scorr15 = corr(real15,output15,'Type','Spearman');
            scorr20 = corr(real20,output20,'Type','Spearman');
            scorr25 = corr(real25,output25,'Type','Spearman');
            scorr30 = corr(real30,output30,'Type','Spearman');
            scorr35 = corr(real35,output35,'Type','Spearman');
            scorr40 = corr(real40,output40,'Type','Spearman'); 
            
            % Saving metrics
            % mse
            mse_v(1,1) = mse10;mse_v(2,1) = mse15;mse_v(3,1) = mse20;
            mse_v(4,1) = mse25;mse_v(5,1) = mse30;mse_v(6,1) = mse35;
            mse_v(7,1) = mse40;
            
            % rmse
            rmse_v(1,1) = rmse10;rmse_v(2,1) = rmse15;rmse_v(3,1) = rmse20;
            rmse_v(4,1) = rmse25;rmse_v(5,1) = rmse30;rmse_v(6,1) = rmse35;
            rmse_v(7,1) = rmse40;
            
            % nmse
            nmse_v(1,1) = nmse10;nmse_v(2,1) = nmse15;nmse_v(3,1) = nmse20;
            nmse_v(4,1) = nmse25;nmse_v(5,1) = nmse30;nmse_v(6,1) = nmse35;
            nmse_v(7,1) = nmse40;
            
            % nrmse
            nrmse_v(1,1) = nrmse10;nrmse_v(2,1) = nrmse15;nrmse_v(3,1) = nrmse20;
            nrmse_v(4,1) = nrmse25;nrmse_v(5,1) = nrmse30;nrmse_v(6,1) = nrmse35;
            nrmse_v(7,1) = nrmse40;
            
            % pcorr
            pcorr_v(1,1) = pcorr10;pcorr_v(2,1) = pcorr15;pcorr_v(3,1) = pcorr20;
            pcorr_v(4,1) = pcorr25;pcorr_v(5,1) = pcorr30;pcorr_v(6,1) = pcorr35;
            pcorr_v(7,1) = pcorr40;
            
            % scorr
            scorr_v(1,1) = scorr10;scorr_v(2,1) = scorr15;scorr_v(3,1) = scorr20;
            scorr_v(4,1) = scorr25;scorr_v(5,1) = scorr30;scorr_v(6,1) = scorr35;
            scorr_v(7,1) = scorr40;
        end
        
        
        
        % Construct Bland-Altman Plot
        function [fig_1,fig_2] = BlandAltmanPlot(obj,real,output)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to create the Bland-Altman plot and the error histogram.
            % 
            % Inputs:
            %           - real -> target signal
            %           - output -> neural network's output signal
            % Returns: 
            %           - fig_1 -> Bland-Altman Plot
            %           - fig_2 -> Histogram Plot
            % ----------------------------------------------------------------------------------------------------------
  
            % error
            yy = real - output;
            
            % average between real and output
            xx = (real+output)/2;
            
            % mean error
            mean_error = ones(size(real)) * mean(yy);
            
            % confidance interval (95.5%)
            CI_min = mean_error - 1.96 * std(yy);
            CI_max = mean_error + 1.96 * std(yy);
            
            fig_1 = figure('visible','off');
            plot(xx,yy,'o'); hold on;
            plot(xx,mean_error,'k','LineWidth',2);
            plot(xx,CI_max,'r','LineWidth',2); 
            plot(xx,CI_min,'r','LineWidth',2);
            
            % bias
            x = sort(xx);
            text(double(x(end)),double(mean_error(end)+0.07),'Bias','fontWeight','bold');
            text(double(x(end)),double(mean_error(end)-0.07),num2str(mean_error(end),3),'fontWeight','bold');
            
            % CI
            x = sort(xx);
            x = x(end);
            text(double(x),double(CI_min(end)-0.07),'CI_9_5-','fontWeight','bold','color','r');
            text(double(x),double(CI_min(end)+0.07),num2str(CI_min(end),3),'fontWeight','bold');
            
            text(double(x),double(CI_max(end)+0.07),'CI_9_5+','fontWeight','bold','color','r');
            text(double(x),double(CI_max(end)-0.07),num2str(CI_max(end),3),'fontWeight','bold');
                        
            xlim([min(xx) max(xx)]); 
            ylim([min(yy) - 0.1 max(yy) + 0.1]);
            legend('Measures','Bias','CI_9_5 Min','CI_9_5 Max',...
                'Location','best');
            title('Bland-Altman Plot');
            xlabel('Average of Target vs Estimation (N.m)');
            ylabel('Target - Estimation (N.m)');
            
            % histogram
            fig_2 = figure('visible','off');
            histogram(yy,'Orientation','horizontal','Normalization','probability'); hold on;
            yline(CI_max(1),'r','LineWidth',2); hold on;
            yline(CI_min(1),'r','LineWidth',2); hold on;
            yline(mean_error(1),'k','LineWidth',2);
            xticklabels(xticks*100);
            
            xlim([0 inf]); 
            legend('Histogram','CI_9_5 Max','CI_9_5 Min','Bias',...
                'Location','best');
            title('Histogram plot');
            xlabel('Relative incidence (%)');
            ylabel('Target - Estimation (N.m)');          
        end
        
        % Plot estimation vs real
        function fig = PlotEstimation(obj,real,output)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to plot the neural network's estimation along with the target signal.
            % 
            % Inputs:
            %           - real -> target signal
            %           - output -> neural network's output signal
            % Returns: 
            %           - fig -> neural network's estimation
            % ----------------------------------------------------------------------------------------------------------

            fig = figure('visible','off');
            plot(output,'linewidth',2); 
            hold on;
            plot(real,'linewidth',2);
            
            legend('Estimation','Target','Location','best');
            xlabel('Samples'); ylabel('Torque (N.m)');
            xlim([1 length(real)]); ylim([min(real)-0.5 max(real)+0.5]);
            title('Estimation result');
        end
        
        % Plot best fit and R2
        function fig = PlotLinearFit(obj,real,output,N)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to plot the best fit.
            % 
            % Inputs:
            %           - real -> target signal
            %           - output -> neural network's output signal
            %           - N -> degree of the polynomial fit
            % Returns: 
            %           - fig -> best fit with degree N with the R2
            % ----------------------------------------------------------------------------------------------------------
            
            % create equation
            [P,~] = polyfit(real,output,N);
            yy = polyval(P,real);
            
            % calculate R2
            R2 = 1 - sum((real-output).^2)/sum((real-mean(real)).^2);
            
            fig = figure('visible','off');
            plot(real,output,'s');
            hold on;
            plot(real,yy,'k','LineWidth',2);
            hold on;
            plot(real,real,'--r');            
            
            legend('Estimation vs Target',...
                strcat('Best Fit with R^2: ',num2str(R2,2)),'Ideality','Location','best');
            xlabel('Target Torque (N.m)'); 
            ylabel('Estimated Torque (N.m)');
            xlim([min(real)-0.1 max(real)+0.1]); 
            ylim([min(output)-0.1 max(output)+0.1]);
            title('Linear Regression');
            
        end
        
        % Plot loss
        function fig = PlotLoss(obj,type_net,info)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to plot loss of the training process.
            % 
            % Inputs:
            %           - type_net -> type of neural network
            %           - info -> network's information that MATLAB's toolbox returns.
            % Returns: 
            %           - fig -> figure of loss curve
            % ----------------------------------------------------------------------------------------------------------
            
            if (strcmp(type_net,'MLP'))
                trainLoss = info.perf;
                validationLoss = info.vperf;
            elseif (strcmp(type_net,'NARX'))
                trainLoss = info.perf;
                validationLoss = info.vperf;
            elseif (strcmp(type_net,'LSTM') || strcmp(type_net,'CNN'))
                index = isfinite(info.ValidationLoss);
                epoch_index = find(index == 1);
                for i = 1:length(epoch_index)
                    if i == 1
                        trainLoss(i,1) = info.TrainingLoss(i);
                    else
                        trainLoss(i,1) = mean(info.TrainingLoss(epoch_index(i-1):epoch_index(i)));
                    end
                end
                validationLoss = info.ValidationLoss(index);
            end
            
            fig = figure('visible','off');
            plot(0:1:length(trainLoss)-1,trainLoss,'LineWidth',2);
            hold on
            plot(0:1:length(trainLoss)-1,validationLoss,'LineWidth',2);
            xlim([0 inf]); ylim([0 inf]);
            title('Loss curve');
            xlabel('Epochs'); ylabel('Mean-Squared Error (MSE)');
            legend('Train','Validation','Location','best');
        end
        
        % Filter
        function Y = Filter(obj,X,n,fc,fs,type)
            
            Wn = fc/(fs/2);
            [b,a] = butter(n,Wn,type);
            Y = filtfilt(b,a,X);
            
        end
        
        % Write in file after training
        function [] = WriteFileAfterTraining(obj,fileID,stop,MSE,NMSE,NRMSE,PCorr,SCorr,type_net,type_validation,...
                Epochs,NoNeurons,StopVal,Batch_size,Validation_Freq)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to write the training information and respective metrics after training the neural
            %   network.
            % 
            % Inputs:
            %           - fileID -> file to write the network's information and metrics.
            %           - stop -> time (in seconds) to train the neural network.
            %           - MSE -> matrix with validation and test MSE.
            %           - NMSE -> matrix with validation and test normalized MSE.
            %           - NRMSE -> matrix with validation and test NRMSE.
            %           - PCorr -> matrix with validation and test pearson's correlation coefficient.
            %           - SCorr -> matrix with validation and test spearman's correlation coefficient.
            %           - type_net -> type of neural network (LSTM, CNN, MLP, etc)
            %           - type_validation -> type of validation technique (CV, LOOCV, Holdout)
            %           - Epochs -> number maximum of epochs
            %           - NoNeurons -> number of neurons of the hidden layers
            %           - StopVal -> number maximum of epochs the loss is not improving (for early stop)
            %           - Batch_size -> batch size for each neural network
            %           - Validation_Freq -> validation frequency
            % ----------------------------------------------------------------------------------------------------------
            
            % create file with metadata & main results
            [~,KMin] = min(MSE(1,:));
            [~,KMax] = max(MSE(1,:));

            fprintf(fileID,'Type NNT: %s \nValidation: %s \nEpochs: %i \nStopVal: %i \n',...
                type_net,type_validation,Epochs,StopVal);
            fprintf(fileID,'Neurons: ');
            if (length(NoNeurons) ~= 1)
                for j = 1:length(NoNeurons)
                    fprintf(fileID,'%i\t',NoNeurons(j));
                end
            else
                fprintf(fileID,'%i',NoNeurons);
            end
            fprintf(fileID,'\nBatch size: %i \n',Batch_size);
            fprintf(fileID,'Validation Frequency: %i \n',Validation_Freq);
            fprintf(fileID,'\nTrain elapsed time: %.3f seconds.\n',stop);
            for K = 1:length(MSE) % headers
                if K < length(MSE)
                    fprintf(fileID,'Fold %i \t',K);
                else
                    fprintf(fileID,'Fold %i \n',K);
                end
            end
            for K = 1:length(MSE) % results
                if K < length(MSE)
                    fprintf(fileID,'%.3f \t',MSE(1,K));
                else
                    fprintf(fileID,'%.3f \n',MSE(1,K));
                end
            end
            % test CV
            for K = 1:length(MSE) % RMSE
                RMSE(1,K) = sqrt(MSE(1,K));
            end

            % validation CV
            for K = 1:length(MSE) % RMSE
                RMSE(2,K) = sqrt(MSE(2,K));
            end

            fprintf(fileID,'\nBest Fold: %i\n',KMin);
            fprintf(fileID,'Worst Fold: %i\n',KMax);

            fprintf(fileID,'\nValidation Mean MSE: %.3f +/- %.3f N.m. \n',mean(MSE(2,:)),std(MSE(2,:)));
            fprintf(fileID,'Validation Mean RMSE: %.3f +/- %.3f N.m. \n',mean(RMSE(2,:)),std(RMSE(2,:)));
            fprintf(fileID,'Validation Mean NMSE: %.3f +/- %.3f. \n',mean(NMSE(2,:)),std(NMSE(2,:)));
            fprintf(fileID,'Validation Mean NRMSE: %.3f +/- %.3f . \n',mean(NRMSE(2,:)),std(NRMSE(2,:)));
            fprintf(fileID,'Validation Mean Pearson Correlation: %.3f +/- %.3f . \n',mean(PCorr(2,:)),std(PCorr(2,:)));
            fprintf(fileID,'Validation Mean Spearman Correlation: %.3f +/- %.3f . \n',mean(SCorr(2,:)),std(SCorr(2,:)));

            fprintf(fileID,'\nTest Mean MSE: %.3f +/- %.3f N.m. \n',mean(MSE(1,:)),std(MSE(1,:)));
            fprintf(fileID,'Test Mean RMSE: %.3f +/- %.3f N.m. \n',mean(RMSE(1,:)),std(RMSE(1,:)));
            fprintf(fileID,'Test Mean NMSE: %.3f +/- %.3f. \n',mean(NMSE(1,:)),std(NMSE(1,:)));
            fprintf(fileID,'Test Mean NRMSE: %.3f +/- %.3f . \n',mean(NRMSE(1,:)),std(NRMSE(1,:)));
            fprintf(fileID,'Test Mean Pearson Correlation: %.3f +/- %.3f . \n',mean(PCorr(1,:)),std(PCorr(1,:)));
            fprintf(fileID,'Test Mean Spearman Correlation: %.3f +/- %.3f . \n',mean(SCorr(1,:)),std(SCorr(1,:)));
        end
        
        % Write in file validation/test metrics
        function [] = WriteFile4FinalModel(obj,fileID,stop,stop_predict,mse,nmse,nrmse,pcorr,scorr,type_net,type_validation,...
                Epochs,NoNeurons,StopVal,Batch_size,Validation_Freq)

            % ----------------------------------------------------------------------------------------------------------
            % This function is used to write the final model information and respective metrics after prediction
            % 
            % Inputs:
            %           - fileID -> file to write the network's information and metrics.
            %           - stop -> time (in seconds) to train the neural network.
            %           - stop_predict -> time (in seconds) to predict the test subject.
            %           - MSE -> matrix with final model MSE.
            %           - NMSE -> matrix with final model normalized MSE.
            %           - NRMSE -> matrix with final model NRMSE.
            %           - PCorr -> matrix with final model pearson's correlation coefficient.
            %           - SCorr -> matrix with final model spearman's correlation coefficient.
            %           - type_net -> type of neural network (LSTM, CNN, MLP, etc)
            %           - type_validation -> type of validation technique (CV, LOOCV, Holdout)
            %           - Epochs -> number maximum of epochs
            %           - NoNeurons -> number of neurons of the hidden layers
            %           - StopVal -> number maximum of epochs the loss is not improving (for early stop)
            %           - Batch_size -> batch size for each neural network
            %           - Validation_Freq -> validation frequency
            % ----------------------------------------------------------------------------------------------------------
            
            fprintf(fileID,'Type NNT: %s \nValidation: %s \nEpochs: %i \nStopVal: %i \n',...
                type_net,type_validation,Epochs,StopVal);
            fprintf(fileID,'Neurons: ');
            if (length(NoNeurons) ~= 1)
                for j = 1:length(NoNeurons)
                    fprintf(fileID,'%i\t',NoNeurons(j));
                end
            else
                fprintf(fileID,'%i',NoNeurons);
            end
            fprintf(fileID,'\nBatch size: %i \n',Batch_size);
            fprintf(fileID,'Validation Frequency: %i \n',Validation_Freq);
            fprintf(fileID,'\nTrain elapsed time: %.3f seconds.\n',stop);
            fprintf(fileID,'Predict elapsed time per sample: %.5f seconds.\n',stop_predict);
            
            fprintf(fileID,'\nTest Mean MSE: %.3f N.m. \n',mse);
            fprintf(fileID,'Test Mean RMSE: %.3f N.m. \n',sqrt(mse));
            fprintf(fileID,'Test Mean NMSE: %.3f . \n',nmse);
            fprintf(fileID,'Test Mean NRMSE: %.3f . \n',nrmse);
            fprintf(fileID,'Test Mean Pearson Correlation: %.3f . \n',pcorr);
            fprintf(fileID,'Test Mean Spearman Correlation: %.3f . \n',scorr);                 
        end
    end
end