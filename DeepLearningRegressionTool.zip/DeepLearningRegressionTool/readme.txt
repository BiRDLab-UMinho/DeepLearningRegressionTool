Bem-vindo à ferramenta de regressão em Machine Learning (ML)!



O código está organizado em três ficheiros:
- NeuralNetwork_class.m
- MAIN.m
- stopIfAccuracyNotImproving.m



O ficheiro NeuralNetwork_class.m é uma classe que contém todas as funções necessárias para fazer o import dos dados (os dados devem estar guardados em disco) e para executar os algoritmos de ML.
Cada uma das funções presentes na classe tem uma pequena descrição. Notar que as funções GetTrainData() e GetTestData() devem ser adaptadas para cada utilizador desta ferramenta.

O ficheiro MAIN.m é responsável por fazer o call das funções pertencentes à classe NeuralNetwork_class.m. Note-se que, para manter o rigor e coerência desta ferramenta de ML, qualquer nova função que se queira adicionar deve ser colocada no ficheiro NeuralNetwork_class.m e não no ficheiro MAIN.m. 
De seguida, encontra-se uma breve explicação de cada secção apresentada no ficheiro MAIN.m:

Secção 1) main directory:
	Nesta secção são indicadas as diretorias (i) "dir_data", responsável pelo import dos dados a utilizar na ferramenta; e (ii) "dir_", que corresponde à diretoria onde se pretende guardar a seed. Cada utilizador deve alterar as diretorias das variáveis "dir_data" e "dir_", conforme necessário.

Secção 2) Creating seed (if not exist) & Data division:
	Nesta secção é criada a seed para manter a reprodutibilidade do código. A seed criada é guardada na diretoria apresentada pela variável "dir_". Caso a seed já exista, a ferramenta utiliza essa mesma seed. 
	Por outro lado, é ainda feita a divisão dos dados entre treino e teste, sendo que este teste servirá apenas para testar o modelo final. É importante salientar que, caso o utilizador queira utilizar todos os sujeitos na validação cruzada, na função "datasample()", é necessário substitutir o 1 por 0, como a seguir se encontra exemplificado: 
		
			test_finalmodel = datasample(dataset,1,'Replace',false);  ---------------->  test_finalmodel = datasample(dataset,0,'Replace',false);

Secção 3) Organize all data into a struct:
	Nesta secção pede-se ao utilizador que introduza a diretoria onde pretende guardar os resultados, sendo criada uma pasta de resultados através da variável "dir_". 
	Por outro lado, nesta secção é onde a instância da classe NeuralNetwork_class.m é criada. 
	Pede-se também ao utilizador que introduza dados relativos ao comprimento do trial (trial_length), número de sujeitos (NoSubjects), número de trials (NoTrials), número de velocidades (NoVelocities) e o tipo de normalização dos dados (MAX-MIN, MEAN-STD e MEDIAN). Note-se que podem ser acrescentadas ou excluídas variáveis considerando cada caso de estudo. No entanto, é necessário alterar a variável "totalTrialsub" consoante as modificações implementadas. 
	A partir dos dados introduzidos pelo utilizador, a ferramenta irá fazer a divisão e import dos dados de treino e teste.

Secção 4) Type of Neural Network, Validation Technique & Final Model Construction:
	Nesta secção, o utilizador deve introduzir o nome da rede neuronal que deseja implementar (MLP, LSTM ou CNN) e deve também introduzir uma das opções desejadas (1 ou 2, onde 1 representa fazer validação cruzada e 2 representa construir o modelo final). 
	Caso o utilizador escolha a opção 1, deverá indicar que método de validação cruzada que deseja implementar (LOOCV ou CV, representando Leave-One-Subject-Out Cross-Validation e Cross-Validation, respetivamente). Contudo, nesta versão da ferramenta, apenas o algoritmo LOOCV está funcional. Caso o utilizador escolha a opção 2, o método de validação que é automaticamente escolhido é o Holdout. 
	Por outro lado, como a LSTM geralmente lida com sequências, caso esta rede neuronal seja a escolhida, pede-se ao utilizador que defina o tamanho desejado da sequência (SequenceLength). 
	Mais ainda, tanto para a LSTM como para a CNN, pede-se ao utilizador que introduza o batch size (Batch_size) desejado. Note-se que no caso da LSTM, o "Batch_size" corresponde ao número de sequências que serão agrupadas, ao passo que no caso da CNN, esta variável corresponde ao número de samples que é agrupado. 
	Por último, é criada uma pasta (através da variável "directory") com o nome da rede neuronal escolhida dentro da pasta anteriormente criada pelo utilizador para guardar os resultados. 

Secção 5) Create NN model & Run: 
	Nesta secção, é pedido ao utilizador que introduza o número de neurónios (NoNeurons), o número de épocas (Epochs) e o número épocas que a loss de validação pode aumentar (StopVal) durante o treino da rede. Note-se que, em validação cruzada, não se deve utilizar a técnica de Early Stop! Nesse sentido, as variáveis "Epochs" e "StopVal" devem tomar o mesmo valor introduzido pelo utilizador.

		**** VALIDAÇÃO CRUZADA ****
		Caso o utilizador tenha selecionado a opção de validação cruzada utilizando o método LOOCV, dá-se início ao processo de validação cruzada através de um ciclo for. 
		Exemplificando, caso se tenham selecionado 10 sujeitos para validação cruzada, o ciclo for deve conter 10 iterações. Por cada iteração, é criada uma pasta (através da variável "folder_name") com o respetivo nome da iteração e é criado um dataset com dados de treino e outro com dados de teste (sendo que este teste é de validação cruzada e é diferente do teste anteriormente escolhido para testar o modelo final).
		Uma vez feita a divisão dos dados, o dataset de treino é normalizado através da função "DataNormalization()" e as configurações que possibilitam normalizar qualquer tipo de dados são guardadas em dois ficheiros .mat, nomeadamente, "XConfig.mat" e "YConfig.mat", que permitem normalizar os predictors (inputs do modelo) e a response (output do modelo), respetivamente. Com estas configurações, normaliza-se o dataset de teste através da função "TestNormalization()".
		Seguidamente, o algoritmo escolhe automaticamente um sujeito que será usado como validação durante o treino da rede neuronal e esse sujeito é removido do dataset de treino na respetiva iteração. O sujeito escolhido é diferente de iteração para iteração. Aos dataset de treino é feito o shuffle dos dados, através da função "ShuffleData()". O shuffle dos dados é feito por trial para manter a ordem temporal dos dados sequenciais. No entanto, se o utilizador optar por um shuffle por sample, pode definir isso no comando trainingOptions da toolbox do MATLAB.

		Caso a LSTM ou CNN tenha sido a rede neuronal escolhida pelo utilizador, os datasets de treino, validação e teste de validação cruzada são organizados em sequências de tamanho igual ao definido pelo utilizador na variável "SequenceLength", através das funções "Train_Val_Sequence()" e "Test_Sequence()". 
		De forma a se efetuar validação época a época, a variável "Validation_Freq" deve ser ajustada para tal (já se encontra automático no código).
		Recorrendo à função "GenerateLSTM()", é então possível criar a rede LSTM. Para se alterar a sua arquitetura (especificando as layers e as options), é necessário editar a referida função na classe NeuralNetwork_class.m.

		Caso a MLP tenha sido a rede neuronal escolhida pelo utilizador, é necessário fornecer à rede os índices de treino e os índices de validação, através das variáveis "trainId" e "valId". Por defeito, o utilizador deve indicar os dados de validação à rede de forma a manter a mesma implementação que as redes LSTM e CNN.
		Recorrendo à função "GenerateMLP()", é então possível criar a rede MLP. 
		Para se alterar a sua arquitetura ou opções de treino, é necessário editar a referida função na classe NeuralNetwork_class.m.

		Uma vez criada a rede neuronal desejada, procede-se ao seu treino, utilizando a função "trainNetwork()" no caso da LSTM e CNN e a função "train()" no caso da MLP. 
		É importante salientar que os valores da loss de validação e o estado da rede neuronal são guardados a cada época. Isto permite que se aceda ao estado da rede neuronal na época onde se obteve a melhor performance. Para isso, no caso da LSTM e CNN, determina-se a época onde se registou a menor loss de validação e faz-se o load da rede neuronal nessa época. No caso da MLP, esta rede já faz o load da rede neuronal na melhor época por defeito. Uma vez feito o load do estado rede neuronal na melhor época, para a rede neuronal selecionada pelo utilizador, efetua-se o predict dos dados de validação e de teste de validação cruzada, através da função "predict()".
		Desnormalizam-se os outputs da rede neuronal e calculam-se 5 métricas de validação e teste, através da função "CalculateMetrics()", nomeadamente o Mean Square Error (MSE), Normalized MSE (MSE), Normalized Root MSE (NRMSE), Pearson Correlation (PCorr) e Spearman Correlation (SCorr). Determina-se também o Bland-Altman Plot e o Best Linear Fit para as previsões do dataset de teste de validação cruzada. 
		Calculadas as métricas, avança-se para a segunda iteração de validação cruzada, onde um novo sujeito de validação e teste são escolhidos e assim sucessivamente.
		Finalmente, terminadas todas as iterações de validação cruzada, informações relativas ao tempo de treino (stop), métricas, tipo de rede neuronal (type_net), tipo de validação (type_validation), Epochs, NoNeurons, StopVal, Batch_size e Validation_Freq são registados num ficheiro através da função "WriteFileAfterTraining()".


		**** CONSTRUÇÃO DO MODELO FINAL ****  (not properly working (09/01/2023))
		Caso o utilizador tenha selecionado a opção de construção do modelo final, torna-se possível utilizar a técnica de Early Stop para criação do modelo final, pelo que, desta forma, as variáveis "Epochs" e "StopVal" podem não tomar o mesmo valor. Para isso, é necessário que o ficheiro stopIfAccuracyNotImproving.m esteja na mesma diretoria do MAIN.m e da classe NeuralNetwork_class.m.
		Todo o restante processo é muito semelhante ao descrito acima, modificando no aspeto de se fazer apenas uma iteração (devido ao facto de se utilizar o método Holdout com Early Stop para parar o treino da rede neuronal quando necessário). Nesse sentido, o dataset de treino é normalizado e são guardadas as configuraçãoes para normalizar o dataset de teste. Do conjunto de dados de treino, o algoritmo escolhe aleatoriamente 1 sujeito que servirá de dataset de validação durante o treino para construção do modelo final. Caso o utilizador pretenda escolher mais do que 1 sujeito de validação, deve substituir o 1 pelo número desejado (x) na função "datasample()", como seguidamente se exemplifica:
		val_finalmodel = datasample(dataset,1,'Replace',false);   ---------------->  val_finalmodel = datasample(dataset,x,'Replace',false);

		Os procedimentos que se seguem são exatamente os mesmos descritos anteriormente.

