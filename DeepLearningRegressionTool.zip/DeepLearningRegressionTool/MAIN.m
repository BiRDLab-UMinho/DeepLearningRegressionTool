% ------------------------------------------------------------------------
% @Main function
% Author: Jo�o M. Lopes & Lu�s Moreira
% Jo�o M. Lopes and Lu�s Moreira are with the Center for Microelectromechanical Systems
% University of Minho. 
% Corresponding author to: a74982@alunos.uminho.pt
%                          a74999@alunos.uminho.pt
% ------------------------------------------------------------------------
%%  1) main directory
clear
clc

% Directory to access the data
dir_data = 'C:\Users\luisl\OneDrive - Universidade do Minho\Cloud\Doutoramento\Software\Real Torque Estimation\Working\Deep Learning\SubjectsData';

% Directory for seed
dir_ = 'C:\Users\luisl\OneDrive - Universidade do Minho\Cloud\Doutoramento\Software\Real Torque Estimation\Working\Deep Learning\';
if ~(exist(dir_,'dir'))
    mkdir (dir_);
end

%% 2) Creating seed (if not exist) & Data division
if ~(exist(strcat(dir_,'Seed.mat'),'file'))
    s = rng;
    save(strcat(dir_,'Seed.mat'),'s');
else
    s = load(strcat(dir_,'Seed.mat')); s = s.s;
    rng(s);
end

% Data division for test & training (index)
fprintf('\nPerforming data division for training and test.\n');
dataset = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18];       

% if exists a test for the final model, replace by the number of subjects
test_finalmodel = datasample(dataset,1,'Replace',false);
if ~isempty(test_finalmodel)
    for i = 1:length(test_finalmodel)
        index = find(dataset == test_finalmodel(i));
        if ~isempty(index)
            dataset(index) = [];
        end
    end
end
clearvars -except dataset test_finalmodel s dir_ dir_data

%% 3) Organize all data into a struct
dir_ = strcat(dir_,input(sprintf('\nInsert path for results: %s',dir_),'s'));
if ~(exist(dir_,'dir'))
    mkdir (dir_);
end

Data = {'Ang','Vel','Acc','TA','GAL','Age','Gender','BH','BM','SL','FL','Speed','Tor'};
   
% neural network
nnet = NeuralNetwork_class_v2;

% metadata
% fprintf('\nInsert metadata:\n');
trial_length = input('Trial length: '); 
NoSubjects = input('Number of Subjects: '); 
NoTrials = input('Number of trials per subject: '); 
NoVelocities = input('Number of speeds per subject: '); 
totalTrialsub = trial_length;

% get dataset for cross-validation and for test the final model
type_norm = input('\nType of normalization (MAX-MIN, MEAN-STD, MEDIAN): ','s');

Data4CV = nnet.GetTrainData(dir_data,dataset,totalTrialsub,NoVelocities);
Data4TestFinalModel = nnet.GetTestData(dir_data,test_finalmodel,totalTrialsub,NoVelocities);

%% 4) Type of Neural Network, Validation Technique & Final Model Construction
type_net = input('\nInsert type of neural network (MLP, LSTM, CNN): ','s'); 
desired_option = input('\nInsert the desired option (1 or 2), where 1 - Cross-Validation and 2 - Final Model Construction: ','s');
desired_option = str2double(desired_option);
if desired_option == 1
    type_validation = input('\nInsert cross-validation technique (LOOCV, CV): ','s'); 
else
    type_validation = 'Holdout';
end

% set test data into sequence if LSTM
if (strcmp(type_net,'LSTM')) || (strcmp(type_net,'CNN'))
    SequenceLength = input('\nInsert sequence length: '); 
    Batch_size = input('\nInsert batch size: '); 
end

directory = strcat(dir_,type_net,'\');
if ~exist(directory, 'dir')     
    mkdir(directory);
end

%% 5) Create NN model & Run
NoNeurons = input('\nInsert the number of neurons: ');
Epochs = input('Insert the number of epochs: ');
StopVal = input('Insert the maximum number of epochs that can fail: ');

MSE = []; NMSE = []; NRMSE = [];
PCorr = []; SCorr = [];

% start time
start = tic;
if desired_option == 1
    if (strcmp(type_validation,'LOOCV'))

        model = cell(2,NoSubjects);

        init_pos = 1;                                              % for leave-one-out 
        final_pos = trial_length * NoTrials;                        % cross validation (LOOCV)

        for K = 1:length(dataset)
            K
            % create folder for each iteration
            folder_name = strcat(directory,'Iteration_',num2str(K),'\');
            mkdir(folder_name)

            % train data
            Train = Data4CV;

            Train.Predictors(init_pos:final_pos,:) = [];
            Train.Response(init_pos:final_pos,:) = [];

            % folder for test
            Test.Predictors = Data4CV.Predictors(init_pos:final_pos,:);
            Test.Response = Data4CV.Response(init_pos:final_pos);

            %rectify NaN values 
            Test.Predictors(:,1) = pchip(1:length(Test.Predictors),Test.Predictors(:,1),1:length(Test.Predictors));
            Test.Response(:,1) = pchip(1:length(Test.Response),Test.Response(:,1),1:length(Test.Response));

            Train.Predictors(:,1) = pchip(1:length(Train.Predictors),Train.Predictors(:,1),1:length(Train.Predictors));
            Train.Predictors(:,2) = pchip(1:length(Train.Predictors),Train.Predictors(:,2),1:length(Train.Predictors));
            Train.Predictors(:,3) = pchip(1:length(Train.Predictors),Train.Predictors(:,3),1:length(Train.Predictors));
            Train.Response(:,1) = pchip(1:length(Train.Response),Train.Response(:,1),1:length(Train.Response));

            % choose a random subject for validation
            available_sub = dataset;
            available_sub(K) = [];
            val_sub = datasample(available_sub,1,'Replace',false);

            index = 1:NoTrials*trial_length:NoTrials*trial_length*length(available_sub);
            val_index = find(available_sub == val_sub);
            val_init = index(val_index);
            val_stop = index(val_index)+ NoTrials*trial_length - 1;

            Validation.Predictors = Train.Predictors(val_init:val_stop,:);
            Validation.Response = Train.Response(val_init:val_stop);

            Train.Predictors(val_init:val_stop,:) = [];
            Train.Response(val_init:val_stop,:) = [];

            % folder for configs
            config_folder = strcat(folder_name,'Configs\');
            mkdir(config_folder)

            % normalize train      
            [Train.Predictors,XConfig] = nnet.DataNormalization(Train.Predictors,type_norm,strcat(config_folder,'XConfig.mat'));
            [Train.Response,YConfig] = nnet.DataNormalization(Train.Response,type_norm,strcat(config_folder,'YConfig.mat'));

            % normalize test
            Test_unnorm = Test;     % for heatmap
            Test.Predictors = nnet.TestNormalization(Test.Predictors,XConfig,type_norm);
            Test.Response = nnet.TestNormalization(Test.Response,YConfig,type_norm);
            
            % normalize validation
            Validation_unnorm = Validation;     % for heatmap
            Validation.Predictors = nnet.TestNormalization(Validation.Predictors,XConfig,type_norm);
            Validation.Response = nnet.TestNormalization(Validation.Response,YConfig,type_norm);

            % shuffle train data
            Train = nnet.ShuffleData(Train,trial_length);

            % train data division into sequences
            if (strcmp(type_net,'LSTM'))

                [Train, Validation] = nnet.Train_Val_Sequence(Train,Validation,...
                    SequenceLength);

                Test.Predictors = nnet.Test_Sequence(Test.Predictors,SequenceLength);

                [NoSequences,~] = size(Train.Predictors);
                Validation_Freq = floor(NoSequences/Batch_size);

                % generate lstm network and options
                [numFeatures,~] = size(Train.Predictors{1});
                [layers,options] = nnet.GenerateLSTM(numFeatures,NoNeurons,1,0.75,Epochs,Batch_size,...
                    Validation,Validation_Freq,StopVal,folder_name,desired_option);

            elseif (strcmp(type_net,'CNN'))

                [Train, Validation] = nnet.Train_Val_Sequence(Train,Validation,...
                    SequenceLength,type_net);

                Test.Predictors = nnet.Test_Sequence(Test.Predictors,SequenceLength,type_net);
                Test.Response = nnet.Test_Sequence(Test.Response,SequenceLength,type_net);

                [NoSequences,~] = size(Train.Predictors);
                Validation_Freq = floor(NoSequences/Batch_size);

                 % generate cnn network and options
                [noFeatures,~] = size(Train.Predictors{1});

                response_length = 1;

                [layers,options] = nnet.GenerateCNN(noFeatures,response_length,0.5,Epochs,Batch_size,...
                    Validation,Validation_Freq,StopVal,folder_name,desired_option);             

            elseif (strcmp(type_net,'MLP'))

                trainFcn = 'traingdx';
                divideFcn = 'divideind';

                Batch_size = length(Train.Predictors);
                Validation_Freq = 1;

                Train.Predictors(end+1:end+totalTrialsub*NoVelocities,:) = Validation.Predictors;
                Train.Response(end+1:end+totalTrialsub*NoVelocities,:) = Validation.Response;

                trainId = 1:(size(Train.Predictors,1)-totalTrialsub*NoVelocities);
                valId = length(trainId)+1:length(Train.Predictors);

                net = nnet.GenerateMLP(NoNeurons,trainFcn,divideFcn,Epochs,0,...
                    0,StopVal,trainId,valId);
            else
                error('Not available algorithm. Retry with LSTM, CNN, MLP.');
            end

            % train the neural network
            if (strcmp(type_net,'LSTM') || strcmp(type_net,'CNN')) 
                [net,info] = trainNetwork(Train.Predictors,cell2mat(Train.Response),layers,options);   


                % find best epoch
                val_loss = info.ValidationLoss(isfinite(info.ValidationLoss));
                val_loss = val_loss(2:end);
                [~,minimum_index] = min(val_loss);

                model{2,K} = info;
                delete(findall(0));

            elseif (strcmp(type_net,'MLP'))
                [net,info] = train(net,Train.Predictors',Train.Response',...
                    'CheckpointFile',strcat(folder_name,'Checkpoint_Epoch'),'CheckpointDelay',0);
                model{2,K} = info;
            end

            % save model into cell
            if (strcmp(type_net,'LSTM') || strcmp(type_net,'CNN')) 
                current_dir = pwd;
                clear net;
                
                cd(folder_name);
                files = dir;
                files = {files.name}';
                pos_files = strfind(files,strcat('__',num2str(minimum_index*Validation_Freq),'__'));
                pos_files = find(~cellfun('isempty',pos_files));
                
                files = files{pos_files};
                load(files);
                delete('*.mat')
                cd(current_dir);
            else
                current_dir = pwd;
                cd(folder_name);
                load('Checkpoint_Epoch.mat');
                cd(current_dir);
                net = checkpoint.net;
            end
            model{1,K} = net;

            % save loss curve
            fig = nnet.PlotLoss(type_net,info);
            saveas(fig,strcat(directory,'Loss_curve_Fold_',int2str(K),'.fig'));
            saveas(fig,strcat(directory,'Loss_curve_Fold_',int2str(K),'.png'));
            close all;

            % predict cross-validation data
            if (strcmp(type_net,'LSTM'))
                % test fold
                output = cell2mat(predict(net,Test.Predictors)')';
                real = Test.Response;

                % validation fold
                output_val = cell2mat(predict(net,Validation.Predictors)')';
                real_val = cell2mat(Validation.Response')';
            elseif (strcmp(type_net,'MLP'))
                 % test fold
                output = net(Test.Predictors')';
                real = Test.Response;

                % validation fold
                output_val = net(Validation.Predictors)';
                real_val = Validation.Response;
            elseif(strcmp(type_net,'CNN'))
                % test fold
                output = (predict(net,Test.Predictors)')';
                real = Test.Response;

                % validation fold
                output_val = (predict(net,Validation.Predictors)')';
                real_val = cell2mat(Validation.Response')';
            end

            % output reverse normalization
            output = nnet.Denormalization(output,YConfig,type_norm);
            output_val = nnet.Denormalization(output_val,YConfig,type_norm);

            % target reverse normalization (for validation)
            real = nnet.Denormalization(cell2mat(real),YConfig,type_norm);  % cell2mat acrescentado
            real_val = nnet.Denormalization(real_val,YConfig,type_norm);
            
            % Data for HeatMap
            Data4HM{1,K}(1,:) = real;
            Data4HM{1,K}(2,:) = output;

            % evaluate CV-test metrics
            [mse,nmse,nrmse,pcorr,scorr] = nnet.CalculateMetrics(real,output);

            % save test metrics
            MSE(1,K) = mse;
            NMSE(1,K) = nmse;
            NRMSE(1,K) = nrmse;
            PCorr(1,K) = pcorr;
            SCorr(1,K) = scorr;

            % evaluate validation subject metrics
            [mse,nmse,nrmse,pcorr,scorr] = nnet.CalculateMetrics(real_val,output_val);

            % save test metrics
            MSE(2,K) = mse;
            NMSE(2,K) = nmse;
            NRMSE(2,K) = nrmse;
            PCorr(2,K) = pcorr;
            SCorr(2,K) = scorr;        

            init_pos = final_pos + 1;
            final_pos = init_pos + totalTrialsub*NoVelocities - 1;

            % Bland-Altman Plot
            [fig_1,fig_2] = nnet.BlandAltmanPlot(real,output);
            saveas(fig_1,strcat(folder_name,'Bland-Altman_CV_Test.fig'));
            saveas(fig_2,strcat(folder_name,'Histogram_CV_Test.fig'));

            % Plot best linear fit with R2
            fig = nnet.PlotLinearFit(real,output,1);
            saveas(fig,strcat(folder_name,'LinearFit_CV_Test.fig'));

            % Plot estimation
            fig = nnet.PlotEstimation(real,output);
            saveas(fig,strcat(folder_name,'CV_TestSubject.fig'));
        end
    else
        error('Not available method for now.');
    end
    
    % stop time
    stop = toc(start);

    % save data for heat map
    save(strcat(directory,'Data4HM.mat'),'Data4HM','-v7.3');
    
    % save all models
    save(strcat(directory,'Models.mat'),'model','-v7.3');
    fileID = fopen(strcat(directory,'readme.txt'),'w');

    % file with metadata & main results of training
    nnet.WriteFileAfterTraining(fileID,stop,MSE,NMSE,NRMSE,PCorr,SCorr,...
        type_net,type_validation,Epochs,NoNeurons,StopVal,Batch_size,...
        Validation_Freq);
    fclose(fileID);
    
else
%     
%     model = cell(2,1);   
%     
%     % create folder for each iteration
%     folder_name = strcat(directory,'Test','\');
%     mkdir(folder_name)
% 
%     % train data
%     Train = Data4CV;
%     
%     % folder for configs
%     config_folder = strcat(folder_name,'Configs\');
%     mkdir(config_folder)
% 
%     % normalize train
%     [Train.Predictors,XConfig] = nnet.DataNormalization(Train.Predictors,type_norm,strcat(config_folder,'XConfig.mat'));
%     [Train.Response,YConfig] = nnet.DataNormalization(Train.Response,type_norm,strcat(config_folder,'YConfig.mat'));
%     
%     % choose a random subject for validation
%     val_finalmodel = datasample(dataset,1,'Replace',false);
%     if ~isempty(val_finalmodel)
%         for i = 1:length(val_finalmodel)
%             index = find(dataset == val_finalmodel(i));
%         end
%     end
%     
%     available_sub = dataset;
%     index_ = 1:NoTrials*trial_length*NoVelocities:NoTrials*trial_length*NoVelocities*length(available_sub);
%     val_index = index;
%     val_init = index_(val_index);
%     val_stop = index_(val_index)+ NoTrials*trial_length*NoVelocities - 1;
% 
%     Validation.Predictors = Train.Predictors(val_init:val_stop,:);
%     Validation.Response = Train.Response(val_init:val_stop);
% 
%     Train.Predictors(val_init:val_stop,:) = [];
%     Train.Response(val_init:val_stop,:) = [];
% 
%     % shuffle train data
%     Train = nnet.ShuffleData(Train,trial_length);
% 
%     % train data division into sequences
%     if (strcmp(type_net,'LSTM'))
% 
%         [Train, Validation] = nnet.Train_Val_Sequence(Train,Validation,...
%             trial_length);
% 
%         [NoSequences,~] = size(Train.Predictors);
%         Validation_Freq = NoSequences/Batch_size;
% 
%         % generate lstm network and options
%         [numFeatures,~] = size(Train.Predictors{1});
%         [layers,options] = nnet.GenerateLSTM(numFeatures,NoNeurons,1,0.05,Epochs,Batch_size,...
%             Validation,Validation_Freq,StopVal,folder_name,desired_option);
% 
%     elseif (strcmp(type_net,'CNN'))       
%         %% Sequence-to-point
%         [noPointsTrain,noFeatures] = size(Train.Predictors);
%         % Construction multidimensional matrix
%         pos1 = 1;
%         pos2 = tdelay;
%         dim = 1;
%         while pos2 <= noPointsTrain
%             Train_.Predictors(:,:,dim) = Train.Predictors(pos1:pos2,:);
%             Train_.Response(:,:,dim) = Train.Response(pos2,1);
%             pos1 = pos1 + 1;
%             pos2 = pos2 + 1;
%             dim = dim + 1;
%         end
% 
%         [noPointsVal,~] = size(Validation.Predictors);
%         pos1 = 1;
%         pos2 = tdelay;
%         dim = 1;
%         while pos2 <= noPointsVal
%             Validation_.Predictors(:,:,dim) = Validation.Predictors(pos1:pos2,:);
%             Validation_.Response(:,:,dim) = Validation.Response(pos2,1);
%             pos1 = pos1 + 1;
%             pos2 = pos2 + 1;
%             dim = dim + 1;
%         end
% 
%         Train.Predictors = permute(Train_.Predictors,[2 1 3]);
%         Train.Predictors = permute(Train_.Predictors,[1 2 4 3]);
%         Train.Response = permute(Train_.Response,[2 1 3]);
%         Train.Response = permute(Train_.Response,[4 2 1 3]);
% 
%         Validation.Predictors = permute(Validation_.Predictors,[2 1 3]);
%         Validation.Predictors = permute(Validation_.Predictors,[1 2 4 3]);
%         Validation.Response = permute(Validation_.Response,[2 1 3]);
%         Validation.Response = permute(Validation_.Response,[4 2 1 3]);
% 
% 
%         [noPointsTest,~] = size(Test.Predictors);
%         pos1 = 1;
%         pos2 = tdelay;
%         dim = 1;
%         while pos2 <= noPointsTest
%             Test_.Predictors(:,:,dim) = Test.Predictors(pos1:pos2,:);
%             pos1 = pos1 + 1;
%             pos2 = pos2 + 1;
%             dim = dim + 1;
%         end
% 
%         Test.Predictors = permute(Test_.Predictors,[2 1 3]);
%         Test.Predictors = permute(Test_.Predictors,[1 2 4 3]);
%         
%         Test.Predictors(1:tdelay,1:12,1,(size(Test.Predictors,4)):(size(Test.Predictors,4)+tdelay-1)) = 0;
% 
%         Train.Predictors(1:tdelay,1:12,1,(size(Train.Predictors,4)):(size(Train.Predictors,4)+tdelay-1)) = 0;
%         Train.Response(1,1,1,(size(Train.Response,4)):(size(Train.Response,4)+tdelay-1)) = 0;
%         
%         Validation.Predictors(1:tdelay,1:12,1,(size(Validation.Predictors,4)):(size(Validation.Predictors,4)+tdelay-1)) = 0;
%         Validation.Response(1,1,1,(size(Validation.Response,4)):(size(Validation.Response,4)+tdelay-1)) = 0;
%         
%         Validation_Freq = size(Train.Predictors,4)/Batch_size;
%                
%         % generate cnn network and options
%         [layers,options] = nnet.GenerateCNN(tdelay,noFeatures,1,1,0.5,Epochs,Batch_size,...
%                     Validation,Validation_Freq,StopVal,folder_name,desired_option);
%             
%     elseif (strcmp(type_net,'MLP'))
% 
%         trainFcn = 'traingdx';
%         divideFcn = 'divideind';
% 
%         Batch_size = length(Train.Predictors);
%         Validation_Freq = 1;
% 
%         Train.Predictors(end+1:end+totalTrialsub*NoVelocities,:) = Validation.Predictors;
%         Train.Response(end+1:end+totalTrialsub*NoVelocities,:) = Validation.Response;
% 
%         trainId = 1:(size(Train.Predictors,1)-totalTrialsub*NoVelocities);
%         valId = length(trainId)+1:length(Train.Predictors);
% 
%         net = nnet.GenerateMLP(NoNeurons,trainFcn,divideFcn,Epochs,0,...
%             0,StopVal,trainId,valId);
% 
%     else
%         error('Not available algorithm. Retry with LSTM, CNN, MLP.');
%     end
%     
%     % train the neural network
%     if (strcmp(type_net,'LSTM') || strcmp(type_net,'CNN')) 
%         [net,info] = trainNetwork(Train.Predictors,Train.Response,layers,options);
% 
%         % find best epoch
%         val_loss = info.ValidationLoss(isfinite(info.ValidationLoss));
%         val_loss = val_loss(2:end);
%         [~,minimum_index] = min(val_loss);
%                 
%         model{2,1} = info;
%         delete(findall(0));
% 
%     elseif (strcmp(type_net,'MLP')) % MLP
%         [net,info] = train(net,Train.Predictors',Train.Response',...
%             'CheckpointFile',strcat(folder_name,'Checkpoint_Epoch'),'CheckpointDelay',0);
%         model{2,1} = info;
%     end
% 
%     % save model into cell
%     if (strcmp(type_net,'LSTM') || strcmp(type_net,'CNN')) 
%         current_dir = pwd;
%         clear net;
% 
%         cd(folder_name);
%         files = dir;
%         files = {files.name}';
%         pos_files = strfind(files,strcat('__',num2str(minimum_index*Validation_Freq),'__'));
%         pos_files = find(~cellfun('isempty',pos_files));
% 
%         files = files{pos_files};
%         load(files);
%         delete('*.mat')
%         cd(current_dir);
%     else
%         current_dir = pwd;
%         cd(folder_name);
%         load('Checkpoint_Epoch.mat');
%         cd(current_dir);
%         net = checkpoint.net;
%     end
%     model{1,1} = net;
% 
%     % save loss curve
%     fig = nnet.PlotLoss(type_net,info);
%     saveas(fig,strcat(directory,'Loss_curve','.fig'));
%     close all;
% 
%     % normalize test
%     Test.Predictors = nnet.TestNormalization(Test.Predictors,XConfig,type_norm);
%     Test.Response = nnet.TestNormalization(Test.Response,YConfig,type_norm);
%     
%     % predict test data
%     start_predict = tic;
%     if (strcmp(type_net,'LSTM'))
%         Test.Predictors = nnet.Test_Sequence(Test.Predictors,trial_length);
%         output = cell2mat(predict(net,Test.Predictors')')';
%         real = Test.Response;
%     elseif (strcmp(type_net,'MLP'))
%         output = net(Test.Predictors')';
%         real = Test.Response;
%     elseif(strcmp(type_net,'CNN'))
%         output = predict(net,Test.Predictors);
%         real = Test.Response;
%     end
%     stop_predict = toc(start_predict)/length(Test.Predictors);
% 
%     % output reverse normalization
%     output2 = output;
%     output = nnet.Denormalization(output,YConfig,type_norm);
% 
%     % ground truth reverse normalization
%     real2 = real;
%     real = nnet.Denormalization(real,YConfig,type_norm);
%     
%     % Save output
%     SaveResponses{1,1}(1,:) = real;
%     SaveResponses{1,1}(2,:) = output;
%     SaveResponses{1,1}(3,:) = real2;
%     SaveResponses{1,1}(4,:) = output2;
%     save(strcat(directory,'SaveResponses.mat'),'SaveResponses','-v7.3');
% 
%     % evaluate test error
%     [mse,nmse,nrmse,pcorr,scorr] = nnet.CalculateMetrics(real,output);
% 
%     % Bland-Altman Plot
%     [fig_1,fig_2] = nnet.BlandAltmanPlot(real,output);
%     saveas(fig_1,strcat(folder_name,'Bland-Altman_Plot_Test.fig'));
%     saveas(fig_2,strcat(folder_name,'Histogram_Test.fig'));
% 
%     % Plot best linear fit with R2
%     fig = nnet.PlotLinearFit(real,output,1);
%     saveas(fig,strcat(folder_name,'LinearFit_Plot_Test.fig'));
% 
%     % Plot estimation
%     fig = nnet.PlotEstimation(real,output);
%     saveas(fig,strcat(folder_name,'TestSubject.fig'));
%     
%     % stop time
%     stop = toc(start);
% 
%     % save real and predict test curves
%     save(strcat(folder_name,'Real.mat'),'real','-v7.3');
%     save(strcat(folder_name,'Predicted.mat'),'output','-v7.3');
%     
%     % save final model
%     save(strcat(directory,'Models.mat'),'model','-v7.3');
%     fileID = fopen(strcat(directory,'readme.txt'),'w');
% 
%     % file with metadata & main results of training
%     nnet.WriteFile4FinalModel(fileID,stop,stop_predict,mse,nmse,nrmse,pcorr,scorr,...
%         type_net,type_validation,Epochs,NoNeurons,StopVal,Batch_size,...
%         Validation_Freq);
%     fclose(fileID);
end